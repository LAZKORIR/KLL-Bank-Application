package edu.miu.cs425.kllbankingsolution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KllBankingSolutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(KllBankingSolutionApplication.class, args);
	}

}
