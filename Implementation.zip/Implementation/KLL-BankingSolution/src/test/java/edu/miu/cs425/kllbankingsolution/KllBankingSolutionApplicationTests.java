package edu.miu.cs425.kllbankingsolution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KllBankingSolutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
