package edu.miu.cs425.kllbankingsolution.utils;

public class UtilityService {
}
